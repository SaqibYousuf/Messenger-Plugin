let firebaseConfig = {
	apiKey: "AIzaSyAlFGoZEPc0rEYAYiUTnNYZmDbnkQdP20c",
	authDomain: "todo-app-25565.firebaseapp.com",
	databaseURL: "https://todo-app-25565.firebaseio.com",
	projectId: "todo-app-25565",
	storageBucket: "gs://todo-app-25565.appspot.com",
	messagingSenderId: "600592089866",
	appId: "1:600592089866:web:1535bd7732529489"
};
module.exports.firebaseConfig = firebaseConfig 